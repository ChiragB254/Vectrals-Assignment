import NextAuth from "next-auth/next";
import GithubProvider from "next-auth/providers/github";
import GoogleProvider from "next-auth/providers/google";
import FacebookProvider from "next-auth/providers/facebook";

const handler = NextAuth({
  providers: [
    GithubProvider({
      clientId: "4a1274c9c3451fa7bbcc",
      clientSecret: "118382debe1137dc0da43f2109e195e66156c032",
    }),
    GoogleProvider({
      clientId: "599724274744-8osb9orjtg7u7u5qdolonncje2devlfc.apps.googleusercontent.com",
      clientSecret: "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",
    }),
    FacebookProvider({
      clientId: "1095896155129480",
      clientSecret: "4a9f8b60bcb215785d507fa615d58acb",
    }),
  ],
});

export { handler as GET, handler as POST };

