const User = require('../models/User');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { validationResult } = require("express-validator");
const config = require("config");
const secretToken = config.get("ACCESS_TOKEN_SECRET");
const refreshToken = config.get("REFRESH_TOKEN_SECRET");

const handleLogin = async (req, res) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { email, password } = req.body;
    // const { user, pwd } = req.body;
    if (!email || !password) return res.status(400).json({ 'message': `Usuario o contraseña incorrectos` });

    const foundUser = await User.findOne({ email: email }).exec();
    console.log(foundUser);
    if (!foundUser) return res.sendStatus(401); //Unauthorized 
    // evaluate password 
    const match = await bcrypt.compare(password, foundUser.password);
    if (match) {
      // create JWTs
      const accessToken = jwt.sign(
        {
          UserInfo: {
            "id": foundUser._id,
          },
        },
        secretToken,
        { expiresIn: "10m" }
      );
      const newRefreshToken = jwt.sign(
        {
          UserInfo: {
            "id": foundUser._id,
          },
        },
        refreshToken,
        { expiresIn: "1d" }
      );

      // Saving refreshToken with current user
      // Store newRefreshToken in refreshToken field
      foundUser.refreshToken = newRefreshToken;

      // Store refreshTokenExpiry with current date + 1 day (1d)
      foundUser.refreshTokenExpiry = new Date(Date.now() + 24 * 60 * 60 * 1000);
      
      const result = await foundUser.save();
      console.log(result);

      // Creates Secure Cookie with refresh token
      res.cookie("jwt", newRefreshToken, {
        httpOnly: true,
        secure: false,
        sameSite: "strict",
        maxAge: 24 * 60 * 60 * 1000,
      });

      // Send authorization roles and access token to user
      res.header("Authorization", `Bearer ${accessToken}`);
      res.json({ accessToken });
    } else {
        res.status(400).json({ errors: [{ msg: `Usuario o contraseña incorrectos` }] });
    }
}

module.exports = { handleLogin };



// app.post("/login", (req, res) => {
//   const user = {
//     id: 1,
//     username: "john.doe",
//   };

//   const accessToken = jwt.sign({ user }, secretKey, { expiresIn: "1h" });
//   const refreshToken = jwt.sign({ user }, secretKey, { expiresIn: "1d" });

//   res
//     .cookie("refreshToken", refreshToken, {
//       httpOnly: true,
//       sameSite: "strict",
//     })
//     .header("Authorization", accessToken)
//     .send(user);
// });