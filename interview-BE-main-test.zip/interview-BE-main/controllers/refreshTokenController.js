const User = require("../models/User");
const jwt = require("jsonwebtoken");
const config = require("config"); // Import cookie-parser
const secretToken = config.get("ACCESS_TOKEN_SECRET");
const refreshTeoken = config.get("REFRESH_TOKEN_SECRET");

const handleRefreshToken = async (req, res) => {
  const cookies = req.cookies;
  if (!cookies?.jwt) return res.status(204).send(); // Return a response and exit the function

  const refreshToken = cookies.jwt;

  try {
    const foundUser = await User.findOne({ refreshToken }).exec();

    if (!foundUser) {
      return res.status(401).send("Access Denied");
    }

    if (
      new Date(foundUser.refreshTokenExpiry).toISOString() >
      new Date().toISOString()
    ) {
      const user = jwt.verify(refreshToken, refreshTeoken);

      if (foundUser._id.toString() !== user.UserInfo.id) {
        return res.sendStatus(403);
      }

      const accessToken = jwt.sign(
        {
          UserInfo: {
            id: foundUser._id,
          },
        },
        secretToken,
        { expiresIn: "10m" }
      );

      // Set the "Authorization" header and send the response
      res.header("Authorization", accessToken);
      res.status(200).json({ accessToken });
    } else {
      // Handle the case when the refreshToken is expired
      return res.sendStatus(401);
    }
  } catch (error) {
    // Handle JWT verification errors
    console.error("JWT verification failed:", error.message);
    return res.sendStatus(500); // Internal Server Error
  }
};

module.exports = { handleRefreshToken };
