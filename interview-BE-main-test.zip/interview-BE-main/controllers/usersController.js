const User = require('../models/User');

const getUser = async (req, res) => {
    console.log(req.user);
    if (!req?.user) return res.status(400).json({ "message": 'User ID required' });
    const users = await User.findOne({ _id: req.user }).exec();
    if (!users) {
        return res.status(204).json({ 'message': `User ID ${req.user} not found` });
    }
    res.json(users);
}

// const deleteUser = async (req, res) => {
//     if (!req?.body?.id) return res.status(400).json({ "message": 'User ID required' });
//     const user = await User.findOne({ _id: req.body.id }).exec();
//     if (!user) {
//         return res.status(204).json({ 'message': `User ID ${req.body.id} not found` });
//     }
//     const result = await user.deleteOne({ _id: req.body.id });
//     res.json(result);
// }


module.exports = {
    // deleteUser,
    getUser
}