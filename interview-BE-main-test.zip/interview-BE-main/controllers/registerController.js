const User = require('../models/User');
const bcrypt = require('bcryptjs');
const { validationResult } = require("express-validator");

const handleNewUser = async (req, res) => {
    const errors = validationResult(req);

    if (!errors.isEmpty()) {
      return res.status(400).json({ errors: errors.array() });
    }

    const { name, email, password } = req.body;

    // check for duplicate usernames in the db
    const duplicate = await User.findOne({ email: email }).exec();
    if (duplicate) return res.status(409).json({ errors: [{ msg: `El usuario ${email} ya existe` }] }); //Conflict 

    try {
        //encrypt the password
        const salt = await bcrypt.genSalt(10);
        const hashedPwd = await bcrypt.hash(password, salt);

        //create and store the new user
        const result = await User.create({
          name: name,
          email: email,
          password: hashedPwd,
        });

        console.log(result);

        res.status(201).json({ 'success': `New user ${email} created!` });
    } catch (err) {
        res.status(500).json({ 'message': err.message });
    }
}

module.exports = { handleNewUser };