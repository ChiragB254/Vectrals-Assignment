const mongoose = require("mongoose");
const Schema = mongoose.Schema;

const todolistSchema = new Schema({
  user_id: {
    type: String,
    required: true,
  },
  task: {
    type: String,
    required: true,
  },
  createdat : Date
});

module.exports = mongoose.model("Todolist", todolistSchema);
